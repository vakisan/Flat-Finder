import React from 'react';
import {Container } from "reactstrap";

const Footer = (props) => {
  return (
    <footer className="footer-custom">
        <Container>
            <h3> Footer will go here</h3>
        </Container>
    </footer>
  );
}

export default Footer;